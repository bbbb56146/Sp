#include "20171614.h"
#define MAX_HASH 20
typedef struct hashNode{//node for hashtable
	int opcode;
	char name[12];
	int child;//store 3/4 's "3", dont need to this project
	int parent;// store 3/4 's "4", dont need to this project
	struct hashNode* next;
}hashNode;
hashNode* hashtable[MAX_HASH];
void makehashtable(int opcode, char* name, int child, int parent) {
	int key = opcode % MAX_HASH;//hash function : distribute by opcode

	hashNode* node = (hashNode*)malloc(sizeof(hashNode));//make node
	node->opcode = opcode;
	strcpy(node->name,name);
	node->child = child;
	node->parent = parent;
	node->next = NULL;

	//check if hashtable is empty, else chaining node
	if (hashtable[key] == NULL) {
		hashtable[key] = node;
	}
	else {
		hashNode* tmp = hashtable[key];
		while (tmp->next!=NULL) {
			tmp = tmp->next;
		}//search
		tmp->next = node;//chaining
	}

}
void makeopcodetable(){
	int num;
	int child,parent;
	char str[12];
	FILE* fp = fopen("opcode.txt","r");
	if (fp == NULL) {
		printf("!!! opcode file is empty\n");
	}
	while (fscanf(fp,"%X\t%s\t%X/%X\n",&num,str,&child,&parent) != EOF) {
		makehashtable( num, str, child, parent);
	}
	fclose(fp);
}
int searchOPTABbyopcode(int opcode, int mode) {
	for (int i = 0; i < 20; i++) {
		hashNode* tmp = hashtable[i];
		while (tmp) {//repeat while tmp is not null
			if (opcode != tmp->opcode) {
				tmp = tmp->next;
			}
			else {
				
				if (mode == 2) {//assemble에서 그냥 존재하는지 알아볼때
					return 1;
				}
				else if (mode == 3) {//assemble 에서 format 이 필요할때
					return tmp->child;
				}
				else if (mode == 4) {//assemble에서 opcode가 필요할때
					return tmp->opcode;
				}
			}
		}
	}
	if (mode == 4) {
		return -1;
	}
	return 0;
}
int searchhashtable(char* mnemonic, int mode) {
	//opcode로 탐색할 때
	for (int i = 0; i < 20; i++) {
		hashNode* tmp = hashtable[i];
		while (tmp) {//repeat while tmp is not null
			if(strcmp(mnemonic,tmp->name)){
				tmp = tmp->next;
			}
			else{
				if (mode == 1) {//opcode mnemonic
					printf("opcode is %X\n", tmp->opcode);
					return 1;
				}
				else if (mode == 2) {//assemble에서 그냥 존재하는지 알아볼때
					return 1;
				}
				else if(mode ==3){//assemble 에서 format 이 필요할때
					return tmp->child;
				}
				else if(mode == 4) {//assemble에서 opcode가 필요할때
					return tmp->opcode;
				}
			}
		}
	}
	if (mode == 1) {
		printf("!!! error : this mnemonic does not exist\n");
	}
	if (mode == 4) {
		return -1;
	}
	return 0;/*
////////이름으로 탐색할 때
	if(mode==1){
	int key = mnemonic[0] % 20;
	hashNode* tmp = hashtable[key];
	if(tmp== NULL){
	 printf("!!! error : this mnemonic's hashtable is empty (mneminic doesnt exist)\n");
	 return 0;
	}
	while (strcmp(mnemonic, tmp->name)) {
		tmp = tmp->next;
		if (tmp == NULL) {//if mnemonic dont exist
			printf("!!! error : this mnemonic does not exist\n");
			return 0;
		}
	}
	printf("opcode is %X\n", tmp->opcode);
	return 1;
	}*/
}
void opcodelist() {//for  "opcodelist"
	for (int i = 0; i < 20; i++) {
		printf("%d : ", i);
		hashNode* tmp = hashtable[i];
		while (tmp) {//repeat while tmp is not null
			printf("[%s,%X] ",tmp->name,tmp->opcode);
			tmp = tmp->next;
			if (tmp) printf("-> ");
		}
		printf("\n");
	}
}
