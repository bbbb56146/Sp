#pragma once
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <dirent.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdbool.h>
#include <stdlib.h>
/*function at memory.c*/
void reset();
int fill(int start, int end, int val);
int edit(int addr, int val);
int dump(int f1,int f2, int type);
/*function at opcode.c*/
void makehashtable(int opcode, char* name, int child, int parent);
void makeopcodetable();
int searchhashtable(char* mnemonic,int mode);//mode 1: opcode mnemonic
void opcodelist();
/*function at 20171614.c*/
void judgecommand();
int isHex(char* str);//check if hex
int get_string(char* str, char* devided, int* start, int comma);
/*function at shell.c*/
void makehistorylist(int factor_flag, char* command, int f1, int f2, int f3, char* opcode);
void dirfn();
int quit();
void helpfn();
void history();
///////func for proj2////
/*function at shell.c*/
int type(char* filename);
/*function at assemble.c*/
int assemble(char* filename);
int symbol();
int pass1(char* filename);
int pass2(char* filename);
int is_COMMENT(char* buffer);
void makeSYMTAB(int loc, char* symbol);
void init_textrecord(int cur_loc, char* record);
void makemodilist(int offset, int length);
void makelocctrlist(int line_num, int addr);
int get_line(char* str, char* devided, int* start, int comma);
int get_reg(char* reg);
int existSYMTAB(char* label, int mode);
/*function at 20171614.c*/
int isDEC(char* str);

////func for proj3///
/*func at load.c*/
int load(char* f1, char* f2, char* f3);
/*func at run.c*/
int search_bp(int addr);
int clear_bp(); 
int print_bp();
int make_bp(int addr);
int run();
int execute(int opcode, int TA, int format, bool immediate);
void print_reg();
/*func at memory.c*/
int read_mem(int val);
/*func at opcode.c*/
int searchOPTABbyopcode(int opcode, int mode);
/*register define*/
#define regA 0
#define regX 1
#define regL 2
#define regPC 8
#define regSW 9
#define regB 3
#define regS 4
#define regT 5
#define regF 6
/*mnemonic define*/
#define ADD   0x18
#define ADDF  0x58
#define ADDR  0x90
#define AND   0x40
#define CLEAR 0xB4    
#define COMP  0x28
#define COMPF 0x88
#define COMPR 0xA0    
#define DIV   0x24
#define DIVF  0x64
#define DIVR  0x9C   
#define FIX   0xC4  
#define FLOAT 0xC0    
#define HIO   0xF4   
#define J     0x3C  
#define JEQ   0x30
#define JGT   0x34
#define JLT   0x38
#define JSUB  0x48
#define LDA   0x0
#define LDB   0x68
#define LDCH  0x50
#define LDF   0x70
#define LDL   0x8
#define LDS   0x6C   
#define LDT   0x74
#define LDX   0x4
#define LPS   0xD0   
#define MUL   0x20
#define MULF  0x60
#define MULR  0x98
#define NORM  0xC8    
#define OR    0x44
#define RD    0xD8   
#define RMO   0xAC    
#define RSUB  0x4C   
#define SHIFTL  0xA4    
#define SIO     0xF0  
#define SSK     0xEC   
#define STA     0x0C   
#define STB     0x78
#define STCH   0x54
#define STF    0x80
#define STI    0xD4  
#define STL    0x14
#define STS    0x7C   
#define STSW  0xE8    
#define STT     0x84
#define STX     0x10
#define SUB     0x1C   
#define SUBF   0x5C   
#define SUBR   0x94
#define SVC     0xB0   
#define TD      0xE0   
#define TIO     0xF8   
#define TIX     0x2C   
#define TIXR    0xB8   
#define WD     0xDC   
// CC define
#define less '<'
#define equal '='
#define greater '>'
