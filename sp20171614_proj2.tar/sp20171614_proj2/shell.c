#include "20171614.h"
typedef struct historyNode {// for command "hi[story]"
	int factor_flag;
	char command[12];
	int factor1;
	int factor2;
	int factor3;
	char opcode[48];
	struct historyNode* next;
}historyNode;
historyNode* head = NULL;//ptr for head of linkedlist
historyNode* tail = NULL;//ptr for tail of linkedlist
void makehistorylist(int factor_flag, char* command, int f1, int f2, int f3, char* opcode) {
	if (factor_flag >= 0) {
		historyNode* tmp = (historyNode*)malloc(sizeof(historyNode));
		strcpy(tmp->command, command);
		strcpy(tmp->opcode, opcode);
		tmp->factor3 = f3;
		tmp->factor2 = f2;
		tmp->factor1 = f1;
		tmp->factor_flag = factor_flag;
		tmp->next = NULL;
		if (head == NULL) {
			head = tmp;
			tail = tmp;
		}
		else {
			tail->next = tmp;
			tail = tmp;//insert
		}
	}
	else {
		printf("!!! number of factor is not 0, 1, 2, 3, 4.\n");
	};//factor_flag is always not minus-> so there is error!
}
void dirfn() {
	DIR *dir;
	struct dirent *entry;
	struct stat stat;

	if (!(dir = opendir(".")))
	{
		printf("!!! error : cannot open directory '.'\n");
		return;
	}

	char buf[1024];
	int cnt = 0;
	printf("\t");
	while ((entry = readdir(dir)))
	{
		lstat(entry->d_name, &stat);

		if (S_ISDIR(stat.st_mode))
			sprintf(buf, "%s/", entry->d_name);
		else if (S_IXUSR & stat.st_mode)
			sprintf(buf, "%s*", entry->d_name);
		else
			sprintf(buf, "%s ", entry->d_name);

		printf("%-25s", buf);

		if (++cnt % 4 == 0)
			printf("\n\t");
	}
//	if (cnt % 4 != 0)
//		printf("\n");

	closedir(dir);
}
int quit() { // make quit flag
	return 1;
}
void helpfn() {//printf command list
	printf("h[elp]\nd[ir]\nq[uit]\nhi[story]\ndu[mp][start, end]\ne[dit] address, value\nf[ill] start, end, value\nreset\nopcode mnemonic\nopcodelist\n");
///////////for proj2///////////////
	printf("assemble filename\n");
	printf("type filename\n");
	printf("symbol\n");
//////////////////////////////////
	return;
}
void history() {// print history list
	historyNode* tmp = head;
	int idx = 1;
	while (tmp) {
		printf("\t%-4d %s", idx++, tmp->command);
		switch (tmp->factor_flag)
		{
		case 4: printf(" %s\n", tmp->opcode); break;
		case 3: printf(" %X, %X, %X\n", tmp->factor1, tmp->factor2, tmp->factor3); break;
		case 2: printf(" %X, %X\n", tmp->factor1, tmp->factor2); break;
		case 1: printf(" %X\n", tmp->factor1); break;
		case 0: printf("\n"); break;
		}
		tmp = tmp->next;
	}
}
////////////////////for proj2/////////////////////////////
int type(char* filename) {//for "type filename"
	//제대로 수행되면 1 리턴, 에러가 있다면 0 리턴
	FILE *fp;// file pointer
	char ch;

	fp = fopen(filename,"rt");
	if(fp==NULL){
		printf("!!! error : %s file is not exist.\n",filename);
		return 0;
	}
//	printf("@@@ file '%s' open is success!\n",filename);

	while(feof(fp)==0){//feof : 내영 있다면 0 반환
		fscanf(fp,"%c",&ch);
		printf("%c",ch);
	}

	fclose(fp);
//	printf("@@@ {type %s} is sucess!!\n", filename);

	return 1;
}
