#include "20171614.h"
extern int lastaddress;
unsigned char memoryspace[0x10000][0x10];//make 1MB memory space it's initialized all zero because of global variable
void reset() {
	for (int i = 0; i < 0x10000; i++) {
		for (int j = 0; j < 0x10; j++) {
			memoryspace[i][j] = 0;
		}
	}
}
int fill(int start, int end, int val) {
	if (start < 0 || start>0xFFFFF || end < start || end>0xFFFFF || val < 0x00 || val>0xFF) {
		printf("!!! SF : factor's boundary error!\n");
		return 0;
	}
	for (int i = start / 0x10; i <= end / 0x10; i++) {
		for (int j = 0; j <  0x10; j++) {
			if (i == start / 0x10 && j < start % 0x10) continue;
			if (i == end / 0x10 && j > end % 0x10) continue;
			memoryspace[i][j] = val;
		}
	}
	return 1;
}
int edit(int addr, int val) {
	if (addr < 0 || addr>0xFFFFF || val < 0x00 || val>0xFF) {
		printf("!!! SF : factor's boundary error!\n");
		return 0;
	}
	int i = addr / 0x10;
	int j = addr % 0x10;
	memoryspace[i][j] = val;
	return 1;
}
int dump(int startaddress, int endaddress,int type) {
	/*set startaddress and endaddress by type(num of factor)*/
	switch (type) {
	case 0: startaddress = lastaddress;
		endaddress = startaddress + 159;
		if (endaddress > 0xFFFFF) {
			printf("!!! segmentation fault : boundary is overed\n");
			return 0;
		}
		break;
	case 1: 
		if (startaddress < 0 || startaddress>0xFFFFF) {
			printf("!!! segmentation fault : start addr is over the boundary.\n");
			return 0;
		}
		endaddress = startaddress + 159;
		if (endaddress > 0xFFFFF) {
			endaddress = 0xFFFFF;
		}
		break;
	case 2: 	
		if (startaddress < 0 || startaddress>0xFFFFF || endaddress < startaddress || endaddress>0xFFFFF) {
		printf("!!! segmentation fault : factor's boundary error!\n");
		return 0;
		}
		break;
	default: return 0;
	}

	int idx_row = startaddress / 0x10;
	int idx_col = startaddress % 0x10;
	for (; idx_row <= endaddress / 0x10; idx_row++) {
		printf("%05X", idx_row*0x10);
		for (int j = 0; j < 0x10; j++) {
			if ((idx_row == startaddress / 0x10 && j < idx_col)|| (idx_row == endaddress / 0x10 && j > endaddress % 0x10)) {
				printf("   ");
			}
			else printf(" %02X", memoryspace[idx_row][j]);
		}
		printf(" ; ");
		for (int j = 0; j < 0x10; j++) {
			if (memoryspace[idx_row][j] < 0x20 || memoryspace[idx_row][j]>0x7E) {
				printf(".");
			}
			else printf("%c", memoryspace[idx_row][j]);
		}
		printf("\n");
	}

	lastaddress = endaddress+1;
	if (lastaddress > 0xFFFFF) {
//		printf("!!! segmentation fault : now lastaddress reached Maximum of boundary(0xFFFFF). so reset the last adress to 0x00000\n");
		lastaddress = 0; 
	}

	return 1;
}
