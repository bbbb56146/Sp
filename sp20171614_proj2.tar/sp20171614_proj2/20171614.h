#pragma once
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <dirent.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdbool.h>
#include <stdlib.h>
/*function at memory.c*/
void reset();
int fill(int start, int end, int val);
int edit(int addr, int val);
int dump(int f1,int f2, int type);
/*function at opcode.c*/
void makehashtable(int opcode, char* name, int child, int parent);
void makeopcodetable();
int searchhashtable(char* mnemonic,int mode);//mode 1: opcode mnemonic
void opcodelist();
/*function at 20171614.c*/
void judgecommand();
int isHex(char* str);//16������ ������ 1����
int get_string(char* str, char* devided, int* start, int comma);
/*function at shell.c*/
void makehistorylist(int factor_flag, char* command, int f1, int f2, int f3, char* opcode);
void dirfn();
int quit();
void helpfn();
void history();
///////func for proj2////
/*function at shell.c*/
int type(char* filename);
/*function at assemble.c*/
int assemble(char* filename);
int symbol();//? ��� ����
int pass1(char* filename);
int pass2(char* filename);
int is_COMMENT(char* buffer);
void makeSYMTAB(int loc, char* symbol);
void init_textrecord(int cur_loc, char* record);
void makemodilist(int offset, int length);
void makelocctrlist(int line_num, int addr);
int get_line(char* str, char* devided, int* start, int comma);
int get_reg(char* reg);
int existSYMTAB(char* label, int mode);
/*function at 20171614.c*/
int isDEC(char* str);

/*register difine*/
#define regA 0
#define regX 1
#define regL 2
#define regPC 8
#define regSW 9
#define regB 3
#define regS 4
#define regT 5
#define regF 6