README
1. how to compile & run
1)Enter "make" in shell. Then 20171614.out is created.
2)Enter "./20171614.out" in shell to run the program. 
To see which commands are executed, type "help" in sicsim>.
in proj2, you can assemble file.
3) After the progam finished, The 20171614.out file is deleted when you type "make clean" in shell.

2. precautions

