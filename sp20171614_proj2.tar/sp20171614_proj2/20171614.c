#include "20171614.h"
int lastaddress = 0;
int rightcommandflag = -1;//changed by num of factors. if command is "opcode", change to 4.
int quitflag = 0;//change to 1 when time to quit 
/* divide string from inputed string*/
int get_string(char* str, char* devided, int *start, int comma) {//start : start idx
	int i;
	int wrong_string = 1;//if right string exist ,change to 0
	int idx = 0;
	int count = 0;

	for (i = *start; i <= (int)strlen(str); i++) {
		if (str[i] == ' ' || str[i] == '\t' || str[i] == '\0' || str[i] == ',') {//before divide string start
			if (str[i] == ',')
				count++;
			if (count >= 2) return 1;//num of comma>2 : wrong str
		}
		else {
			wrong_string = 0;
			devided[idx++] = str[i];//make command array.
		
///////////being comment for proj2/////////////////////////////////////////////////////////////////////////
			if (comma != count) {
			 if(count==0){//case :  edit aa bb 
			  *start = -1;//verify wrong string but factornum++ using start;
			 }
			 return 1;//ex : opcde, AA
			}
			
			if (str[i + 1] == ' ' || str[i + 1] == '\t' || str[i + 1] == '\0' || str[i + 1] == ',') {
				devided[idx] = '\0';
				break;
			}
		}
	}
	*start = i + 1;//next index to start search

	return wrong_string;
}
void judgecommand() {
	/*input the string(command [factor1,factor2,factor3])*/
	char str[1000];
	char ptr[100];//array for string
	fgets(str,1000,stdin);
	str[strlen(str) - 1] = '\0';

	int start = 0;
	int factor_num = 0;
	int fAEF = 0;//factorAlreadyExistedFlag
	char factor_str[10][100];
	char tmp[100];
	if (get_string(str, ptr, &start, 0) == 1) {//check if command devided
		printf("!!! no string\n");
	}
	else {//if devided
		while (!get_string(str, tmp, &start,fAEF)) {//devide the factor
			fAEF = 1;
			strcpy(factor_str[factor_num++], tmp);//store favtors
			memset(tmp, 0, sizeof(tmp));//initialize
		}
		if(start==-1) {
		 factor_num = -1;// to verify factor string is wrong
		}
		
		/*compare commands*/
		
		/*commands with no factor*/
		if (!strcmp("h", ptr) || !strcmp("help", ptr)) {
			rightcommandflag = 0;
			if (factor_num == rightcommandflag) {
				makehistorylist(rightcommandflag, ptr, -1, -1, -1, "INIT");
				helpfn();
			}
			else {
				printf("!!! factor num is too many or too small.\n");
				rightcommandflag = -1;
			}
		}
		else if (!strcmp("d", ptr) || !strcmp("dir", ptr)) {
			rightcommandflag = 0;
			if (factor_num == rightcommandflag) {
				makehistorylist(rightcommandflag, ptr, -1, -1, -1, "INIT");
				dirfn();
				printf("\n");
			}
			else {
				printf("!!! factor num is too many or too small.\n");
				rightcommandflag = -1;
			}
		}
		else if (!strcmp("q", ptr) || !strcmp("quit", ptr)) {
			rightcommandflag = 0;
			if (factor_num == rightcommandflag) {
				makehistorylist(rightcommandflag, str, -1, -1, -1, "INIT");
				quitflag = quit();// quit flag become 1
			}
			else {
				printf("!!! factor num is too many or too small.\n");
				rightcommandflag = -1;
			}
		}
		else if (!strcmp("hi", ptr) || !strcmp("history", ptr)) {
			rightcommandflag = 0;
			if (factor_num == rightcommandflag) {
				makehistorylist(rightcommandflag, str, -1, -1, -1, "INIT");
				history();
			}
			else {
				printf("!!! factor num is too many or too small.\n");
				rightcommandflag = -1;
			}
		}
		else if (!strcmp("reset", ptr)) {
			rightcommandflag = 0;
			if (factor_num == rightcommandflag) {
				makehistorylist(rightcommandflag, ptr, -1, -1, -1, "INIT");
				reset();
			}
			else {
				printf("!!! factor num is too many or too small.\n");
				rightcommandflag = -1;
			}
		}
		else if (!strcmp("opcodelist", ptr)) {
			rightcommandflag = 0;
			if (factor_num == rightcommandflag) {
				makehistorylist(rightcommandflag, ptr, -1, -1, -1, "INIT");
				opcodelist();
			}
			else {
				printf("!!! factor num is too many or too small.\n");
				rightcommandflag = -1;
			}
		}
		/*opcode*/
		else if (!strcmp("opcode", ptr)) {
			rightcommandflag = 4;
			if (factor_num == rightcommandflag - 3){
			 if(searchhashtable(factor_str[0],1)){
			 makehistorylist(rightcommandflag, ptr, -1, -1, -1, factor_str[0]);
			 }
			}
			else{
			 printf("!!! factor num is too small of too many.\n");
			 rightcommandflag = -1;
			}
		}
		/*edit*/
		else if (!strcmp("e", ptr) || !strcmp("edit", ptr)) {
			rightcommandflag = 2;
			int f[2] = { -1, -1 };

			if (factor_num == rightcommandflag) {
				char* pointer;
				for (int i = 0; i < factor_num; i++) {
					if(isHex(factor_str[i])){
						f[i] = (int)strtol(factor_str[i], &pointer, 16);
					}
					else{
					 rightcommandflag = -2;
					 break;
					}
				}
				if(rightcommandflag>=0){
				 if(edit(f[0],f[1])){
				  makehistorylist(rightcommandflag, ptr, f[0], f[1], -1, "INIT");
				 }
				}
				else if(rightcommandflag ==-2) {
				 printf("!!! factor is wrong\n");
				}
			}
			else {
				printf("!!! factor num is too many or too small.\n");
				rightcommandflag = -1;
			}
		}
		/*fill*/
		else if (!strcmp("f", ptr) || !strcmp("fill", ptr)) {
			rightcommandflag = 3;	
			int f[3] = { -1 , -1, -1 };
			if (factor_num == rightcommandflag) {
				char* pointer;
				for (int i = 0; i < factor_num; i++) {
					if (isHex(factor_str[i])){
						f[i] = (int)strtol(factor_str[i], &pointer, 16);
					}
					else {
					 rightcommandflag = -2;
					 break;
					}
				}
				if(rightcommandflag>=0){
				 if(fill(f[0],f[1],f[2])){
				  makehistorylist(rightcommandflag, ptr, f[0], f[1], f[2], "INIT");
				 }
				}
				else if(rightcommandflag==-2){
				 printf("!!! factor is wrong!\n");
				 rightcommandflag = -1;
				}
			}
			else {
				printf("!!! factor num is too many or too small.\n");
				rightcommandflag = -1;
			}
		}
		/*dump*/
		else if (!strcmp("du", ptr) || !strcmp("dump", ptr)) {
			if (factor_num <= 2&&factor_num>=0) {
				rightcommandflag = factor_num;
				int f[2] = { -1,-1 };
				char* pointer;
				for (int i = 0; i < factor_num; i++) {
					if (isHex(factor_str[i])){
						f[i] = (int)strtol(factor_str[i], &pointer, 16);
					}
					else {
					 rightcommandflag = -2;
					 break;
					}
				}
				if (dump(f[0], f[1], rightcommandflag)&&(rightcommandflag>=0)) {//type num = num of factor
					makehistorylist(rightcommandflag, ptr, f[0], f[1], -1, "INIT");
				}
				else if(rightcommandflag==-2){
					printf("!!! factor is wrong!\n");
					rightcommandflag = -1;
				}
			}
			else {
				printf("!!! factor num is too many or too small.\n");
				rightcommandflag = -1;
			}
		}
//////////for proj2/////////////////////////////
		/*type*/
		else if (!strcmp("type", ptr)) {
			rightcommandflag = 4;
			if (factor_num == rightcommandflag-3){
			 	//test
		//		printf("@@@ for test: type command 는 정상적으로 입력됨\n");
				if(type(factor_str[0])){
			 		makehistorylist(rightcommandflag, ptr, -1, -1, -1, factor_str[0]);
				}
				else {
					printf("!!! command type failed.\n");
					rightcommandflag = -1;
				}
			}
			else{
			 printf("!!! factor num is too small of too many.\n");
			 rightcommandflag = -1;
			}
		}

		/*assemble*/
		else if (!strcmp("assemble", ptr)) {
		rightcommandflag = 4;
		if (factor_num == rightcommandflag - 3) {
			//test
		//	printf("\n@@@ for test: assemble command 는 정상적으로 입력됨\n");
			if (assemble(factor_str[0])) {
				makehistorylist(rightcommandflag, ptr, -1, -1, -1, factor_str[0]);
			}
			else {
				printf("!!! command assemble failed.\n");
				rightcommandflag = -1;
			}
		}
		else {
			printf("!!! factor num is too small of too many.\n");
			rightcommandflag = -1;
		}
		}
		/*symbol*/
		else if (!strcmp("symbol", ptr)) {
		rightcommandflag = 0;
		if (factor_num == rightcommandflag) {
			if (symbol()) {
				makehistorylist(rightcommandflag, ptr, -1, -1, -1, "INIT");
			}
			else {
				printf("!!! command symbol failed.\n");
				rightcommandflag = -1;
			}
		}
		else {
			printf("!!! factor num is too many or too small.\n");
			rightcommandflag = -1;
		}
		}
//----------compare command end-----------------------//
		else {
		rightcommandflag = -1;
			printf("!!! this is wrong command,\n");
		}
	}

}//func that input the string and judge this string is right

int isHex(char* str) {
	int rightflag = 1;
	for (int i = 0; i < (int)strlen(str); i++) {
		if (!((str[i] >= '0' && str[i] <= '9') || (str[i] >= 'A' && str[i] <= 'F') || (str[i] >= 'a' && str[i] <= 'f'))) {
			rightflag = 0;
			break;
		}
	}
	return rightflag;
}
int isDEC(char* str) {
	int rightflag = 1;
	for (int i = 0; i < (int)strlen(str); i++) {
		if (!(str[i] >= '0' && str[i] <= '9')) {
			rightflag = 0;
			break;
		}
	}
	return rightflag;
}
int main(){
 makeopcodetable();
 lastaddress = 0;//initialize
 while(!quitflag){
  printf("sicsim>");
  judgecommand();
 }
 return 0;
}
