#pragma once
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <dirent.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdbool.h>
#include <stdlib.h>
/*function at memory.c*/
void reset();
int fill(int start, int end, int val);
int edit(int addr, int val);
int dump(int f1,int f2, int type);
/*function at opcode.c*/
void makehashtable(int opcode, char* name, int child, int parent);
void makeopcodetable();
int searchhashtable(char* mnemonic);
void opcodelist();
/*function at 20171614.c*/
void judgecommand();
int isHex(char* str);
int get_string(char* str, char* devided, int* start, int comma);
/*function at shell.c*/
void makehistorylist(int factor_flag, char* command, int f1, int f2, int f3, char* opcode);
void dirfn();
int quit();
void helpfn();
void history();
