#include "20171614.h"
#define MAX_HASH 20
typedef struct hashNode{//node for hashtable
	int opcode;
	char name[12];
	int child;//store 3/4 's "3", dont need to this project
	int parent;// store 3/4 's "4", dont need to this project
	struct hashNode* next;
}hashNode;
hashNode* hashtable[MAX_HASH];
void makehashtable(int opcode, char* name, int child, int parent) {
	int key = name[0] % MAX_HASH;//hash function : distribute by 1st character of mnemonic

	hashNode* node = (hashNode*)malloc(sizeof(hashNode));//make node
	node->opcode = opcode;
	strcpy(node->name,name);
	node->child = child;
	node->parent = parent;
	node->next = NULL;

	//check if hashtable is empty, else chaining node
	if (hashtable[key] == NULL) {
		hashtable[key] = node;
	}
	else {
		hashNode* tmp = hashtable[key];
		while (tmp->next!=NULL) {
			tmp = tmp->next;
		}//search
		tmp->next = node;//chaining
	}

}
void makeopcodetable(){
	int num;
	int child,parent;
	char str[12];
	FILE* fp = fopen("opcode.txt","r");
	if (fp == NULL) {
		printf("wrwr\n");
	}
	while (fscanf(fp,"%X\t%s\t%X/%X\n",&num,str,&child,&parent) != EOF) {
		makehashtable( num, str, child, parent);
	}
	fclose(fp);
}
int searchhashtable(char* mnemonic) {//for "opcode mnemonic"
	int key = mnemonic[0] % 20;
	hashNode* tmp = hashtable[key];
	if(tmp== NULL){
	 printf("!!! error : this mnemonic's hashtable is empty (mneminic doesnt exist)\n");
	 return 0;
	}
	while (strcmp(mnemonic, tmp->name)) {
		tmp = tmp->next;
		if (tmp == NULL) {//if mnemonic dont exist
			printf("!!! error : this mnemonic does not exist\n");
			return 0;
		}
	}
	printf("opcode is %X\n", tmp->opcode);
	return 1;
}
void opcodelist() {//for  "opcodelist"
	for (int i = 0; i < 20; i++) {
		printf("%d : ", i);
		hashNode* tmp = hashtable[i];
		while (tmp) {//repeat while tmp is not null
			printf("[%s,%X] ",tmp->name,tmp->opcode);
			tmp = tmp->next;
			if (tmp) printf("-> ");
		}
		printf("\n");
	}
}
